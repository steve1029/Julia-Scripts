% Definition for a(x) in the stiffness matrix

function a_val = a_def(node)

% a(x) = 1 + x
a_val = 1 + node; 

end